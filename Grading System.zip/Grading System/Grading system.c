#include<stdio.h>

int Mark(char subName[])
{
    int ENG,MAT,ART,CSC;
    double finalRes;
    int fTerm,mTerm,finalM,ct=0,pres,qt=0,att,dbc;
    printf("Enter first term mark in %s: \n",subName);
    scanf("%d",&fTerm);
    printf("Enter mid term mark in %s: \n",subName);
    scanf("%d",&mTerm);
    cpFinal:
    printf("Enter final mark in %s : \n",subName);
    scanf("%d",&finalM);
    printf("Enter all class test marks  in %s: \n",subName);
        int x;
        printf("Class test :\n");
        scanf("%d",&x);
    printf("Enter quiz mark  in %s: \n",subName);
        int y;
        printf("Quiz test : \n");
        scanf("%d",&y);
    printf("Enter presentation mark  in %s: \n",subName);
    scanf("%d",&pres);
    printf("Enter attendence percentage  in %s: \n",subName);
    scanf("%d",&att);
    printf("Enter dress code and behavior mark  in %s: \n",subName);
    scanf("%d",&dbc);
    finalRes=(double) (fTerm*0.2)+(mTerm*0.2)+(finalM*0.35)+(ct/3*0.05)+(pres*0.05)+(qt/3*0.05)+(att*0.05)+(dbc*0.05);
    return finalRes;
}
float point(int mark){
    float point;
    if(mark>=90 && mark<=100) {
        point=4.00;
    }
    else if(mark>=85 && mark<=87) {
        point=3.7;
    }
    else if(mark>=81 && mark<=84) {
        point=3.4;
    }
    else if(mark>=78 && mark<=80) {
        point=3.1;
    }
    else if(mark>=75 && mark<=77) {
        point=2.8;
    }
    else if(mark>=71 && mark<=74) {
        point=2.5;
    }
    else if(mark>=66 && mark<=70) {
        point=2.2;
    }
    else if(mark>=61 && mark<=65) {
        point=1.5;
    }
    else if(mark>=60) {
        point=1.0;
    }
    else {
        point=0.0;
    }
}
int main(){
    int ENG,MAT,ART,CSC;
    float engP,matP,artP,cscP;
    printf("Enter marks in ENG : \n");
    ENG=Mark("ENG");
    engP=point(ENG);
    printf("Enter marks in MAT : \n");
    MAT=Mark("MAT");
    matP=point(MAT);
    printf("Enter marks in ART : \n");
    ART=Mark("ART");
    artP=point(ART);
    printf("Enter marks in CSC : \n");
    CSC=Mark("CSC");
    cscP=point(CSC);
    printf("Your final marks are : \nENG : %d\tMAT : %d\tART : %d\tCSC : %d\n",ENG,MAT,ART,CSC);
    float SGPA=(engP*3+matP*3+artP*2+cscP*3)/(3+3+2+3);
    printf("YOUR SGPA ON THIS SEMESTER: %.2f\n",SGPA);
    }
   //-------------------------------------------------END----------------------------------------------------

